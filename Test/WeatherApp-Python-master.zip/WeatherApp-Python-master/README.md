# Weather-Computer-App

Language: Python 2.7

Simple weather app that grabs JSON data from openweathermap API and location from freegeoip.net

WeatherApp written using pygame for graphics.

Displays weather in the location you specifically are in using your longitude and latitude .

Includes information such as:
  picture of weather,
  current temperature,
  temperature high,
  temperature low,
  wind speed and
  description of the weather
  
  
TO DO LIST:  Improve picture quality
